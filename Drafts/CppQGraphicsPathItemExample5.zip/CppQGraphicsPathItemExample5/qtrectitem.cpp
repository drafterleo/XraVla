#ifdef _WIN32
//See http://www.richelbilderbeek.nl/CppCompileErrorSwprintfHasNotBeenDeclared.htm
#undef __STRICT_ANSI__
#endif

//#include own header file as first substantive line of code, from:
// * John Lakos. Large-Scale C++ Software Design. 1996. ISBN: 0-201-63362-0. Section 3.2, page 110
#include "qtrectitem.h"

QtRectItem::QtRectItem(QGraphicsItem *parent, QGraphicsScene *scene)
 : QGraphicsRectItem(parent,scene)
{
  this->setFlags(
      QGraphicsItem::ItemIsSelectable
    | QGraphicsItem::ItemIsMovable);

  const double length = 8;
  this->setRect(-length/2.0,-length/2.0,length,length);
}

void QtRectItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
  m_signal_mouse_move();
  QGraphicsRectItem::mouseMoveEvent(event);
}
