#ifndef QTWIDGET_H
#define QTWIDGET_H

#include <QGraphicsView>

///The widget holding the items
struct QtWidget : public QGraphicsView
{
  QtWidget(QWidget *parent = 0);

  ///Pass the key presses to the scene items
  void keyPressEvent(QKeyEvent *event);

  private:
  void OnMouseMove();
};

#endif // QTWIDGET_H
