#ifdef _WIN32
//See http://www.richelbilderbeek.nl/CppCompileErrorSwprintfHasNotBeenDeclared.htm
#undef __STRICT_ANSI__
#endif

//#include own header file as first substantive line of code, from:
// * John Lakos. Large-Scale C++ Software Design. 1996. ISBN: 0-201-63362-0. Section 3.2, page 110
#include "qtwidget.h"


#include <cassert>
#include <cmath>
#include <QGraphicsScene>
#include "qtrectitem.h"
#include "qtpathitem.h"

QtWidget::QtWidget(QWidget *parent)
  : QGraphicsView(new QGraphicsScene,parent)
{
  const int n_items = 18;
  std::vector<QtRectItem *> rects;

  for (int i=0; i!=n_items; ++i)
  {
    const double angle = 2.0 * M_PI * (static_cast<double>(i) / static_cast<double>(n_items));
    const double x1 =  std::sin(angle) * 100.0;
    const double y1 = -std::cos(angle) * 100.0;
    QtRectItem * const rect = new QtRectItem;
    rect->setPos(x1,y1);
    scene()->addItem(rect);
    rects.push_back(rect);
    rect->m_signal_mouse_move.connect(
      boost::bind(&QtWidget::OnMouseMove,this));
  }
  for (int i=0; i<n_items-2; i+=3)
  {
    assert(i + 2 < n_items);
    QtPathItem * const item = new QtPathItem(
      rects[(i+0) % n_items],
      false,
      rects[(i+1) % n_items],
      true,
      rects[(i+2) % n_items]);
    scene()->addItem(item);
  }
}

void QtWidget::keyPressEvent(QKeyEvent *event)
{
  QList<QGraphicsItem *> v = scene()->selectedItems();
  std::for_each(v.begin(),v.end(),
    [event](QGraphicsItem * const item)
    {
      if (QtPathItem * const pathitem = dynamic_cast<QtPathItem *>(item))
      {
        pathitem->keyPressEvent(event);
      }
    }
  );
}

void QtWidget::OnMouseMove()
{
  this->scene()->update();
}
