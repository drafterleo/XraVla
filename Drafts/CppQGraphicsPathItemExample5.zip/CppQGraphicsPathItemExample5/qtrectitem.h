#ifndef QTRECTITEM_H
#define QTRECTITEM_H

#include <QGraphicsRectItem>
#include <boost/signals2.hpp>

struct QtRectItem : public QGraphicsRectItem
{
  QtRectItem(QGraphicsItem *parent = 0, QGraphicsScene *scene = 0);

  boost::signals2::signal<void()> m_signal_mouse_move;
  protected:
  void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
};

#endif // QTRECTITEM_H
